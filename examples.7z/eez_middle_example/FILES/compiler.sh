#!/bin/bash

g++ solver_finder.c++ -o out_finder

g++ solver_u1_u2.c++ -o out_u1_u2

g++ solver_no_eez.c++ -o out_no_eez

