#include<iostream>
#include<stdlib.h>
#include<cmath>
#include<sstream>
#include<fstream>
#include<string>
#include<iomanip>
#include<vector>
#include <typeinfo>
#include <algorithm>
#include <chrono>

using namespace std;

int ll,ll1,ll2;
const double qq = -pow(2.0/3.0,0.5)/M_PI;
double sig,sig1,sig2,temp,res,mtemp,step,ctemp,temp1,zexcl,u1find,u2find,hh,kk,ff1,ff2,fftot,meandis,temp2,ratio0,ratio1,dif1,perc,eez_size,nav,ctot;
int len,u1fin,u2fin,i0,convincr;
double dxx;
double a=1;
double aa;
int prec1=6;
int prec2=2*prec1;

//All quantities exported are in the rescaled (tilded) form
int main(int argn, char **argc ){


    if (argn==2) {

        aa=atoi(argc[1]);  //(K/H^2)
        
    } else {
    cout<<"incorrect number of parameters"<<endl ;
    cout<<"argc[1]=a"<<endl ;
    exit(0);
    }


    /////////////////////
    //IMPORTATION START//
    /////////////////////

    vector <double> ustemp ;
    vector <long double> chendtemp;
    vector <long double> ztemp;
    vector <long double> yytemp;
    ifstream stream;
    string x;


    string name="details.dat";

    stream.open(name);

    stream>>x;

    while (stream.eof() != true){

      ustemp.push_back(atof(x.c_str()));
      stream>>x;
      ztemp.push_back(atof(x.c_str()));
      stream>>x;
      chendtemp.push_back(atof(x.c_str()));
      stream>>x;
      yytemp.push_back(atof(x.c_str()));
      stream>>x;
    }

    stream.close();

    ll1=ustemp.size();
    ll=ll1-1;
    ll2=ll1-2;
    

     long double dx[ll1],xs[ll1],rhs[ll1],dydx1[ll1],yy1[ll1],yy2[ll1],dzdx[ll1],z[ll1],md[ll1],ii[ll1],dis[ll1],pp[ll1],m[ll1],chenddz[ll1],rhs2[ll1];
     double iin[ll1],chend[ll1],chend2[ll1],m1[ll1],m1d[ll1],cc[ll1],test[ll1],testd[ll1];

    
    dxx=1.0/ll;
    

    xs[0]=0;
    for (int i=1;i<ll1;i++){xs[i]=xs[i-1]+dxx;}

    for (int i=0;i<ll1;i++){chend[i]=chendtemp[i];}
    for (int i=0;i<ll1;i++){z[i]=ztemp[i];}
    for (int i=0;i<ll1;i++){yy1[i]=yytemp[i];}


////    ctot=0;
////    for (int i=1;i<ll;i++){ ctot+=chend[i]*pow(xs[i],0.5);}
////    ctot+=chend[ll]*pow(1,0.5)/2.0;
////    ctot=-2.0/(qq*M_PI)*ctot*dxx;
////    
////    for (int k=0;k<ll;k++){
////        temp=0; //First term is zero
////        for (int i=k+1;i<=ll2;i++){temp+=(chend[i]*pow(xs[i] - xs[k],0.5));}
////        temp+=(chend[ll]*pow(xs[ll] - xs[k],0.5))/2.0;
////        temp=-2.0/(qq*M_PI)*temp*dxx;
////        cc[k]=ctot-temp;
////    }
////    cc[ll]=ctot;
////    
////    cout<<ctot<<endl;
////    for (int k=0;k<ll;k++){m[k]=(cc[k+1]-cc[k])/dxx;}
////    m[ll]=0;//Linear interpolation
////    for (int k=0;k<=500;k++) { cout << xs[k] << " " << cc[k] << " "<< m[k] << endl;}
    
    
    
    
    for (int k=0;k<ll2;k++){
        temp=0;
        for (int i=k+1;i<=ll2;i++){temp+=((chend[i] - chend[k])/pow(xs[i] - xs[k],0.5));}
        temp+=(chend[ll] - chend[k])/pow(xs[ll] - xs[k],0.5)/2.0;
        temp=temp*dxx;
        m[k]=-1.0/(qq*M_PI)*(temp+2*chend[k]*pow(1.0-xs[k],0.5));
//        m[k]=(temp+2*chend[k]*pow(1.0-xs[k],0.5));
    }

    m[0]=1.0;
    m[ll]=0;
    m[ll-1]=(m[ll-2]+m[ll])/2.0;//Linear interpolation
    
    for (int k=0;k<ll;k++){md[k]=(m[k+1]-m[k])/dxx;}
    md[ll]=2*md[ll-1]-md[ll-2];//Linear interpolation

   

    for (int k=0;k<=ll2;k++) {
        dzdx[k]=(z[k+1]-z[k])/dxx;
    }
    dzdx[ll]=2*dzdx[ll-1]-dzdx[ll-2];//Linear interpolation
    
  
    for (int k=0;k<ll;k++){dydx1[k]=(yy1[k+1]-yy1[k])/dxx;}
    dydx1[ll]=2*dydx1[ll-1]-dydx1[ll-2];//Linear interpolation

    sig=0;
    for (int i=1;i<=ll2;i++){ sig+=chend[i];}
    sig+=chend[ll]/2.0;
    sig=sig*dxx;
    
     for (int k=0;k<ll;k++){
        temp=chend[0]/2.0;
        for (int i=1;i<=k-1;i++){ temp+=chend[i];}
        if (k>0) {temp+=chend[k];}
        rhs[k]=temp*dxx/sig;
    } //ii(u) calculation where sig_c(U)=1-ii(u)
    

    rhs[ll]=1.0;
    rhs[0]=0;

    for (int k=0;k<=ll2;k++) {
        if (yy1[k+1]>yy1[k]) pp[k]=(rhs[k+1]-rhs[k])/(yy1[k+1]-yy1[k]);
        if (yy1[k]>yy1[k+1]) pp[k]=(rhs[k+1]-rhs[k])/(yy1[k]-yy1[k+1]);
    }

    pp[ll]=2*pp[ll-1]-pp[ll-2];//Linear interpolation
    if (pp[ll] <0) pp[ll]=0;

    
    cout<<" sig "<< sig <<endl;

    
    
    temp=0;
    for (int k=0;k<=ll1;k++){temp+=(yy1[k+1]-yy1[k])*(pp[k+1]*yy1[k+1]+pp[k]*yy1[k]);}
    nav=temp/2.0;
    cout<< "Average N : " << nav <<endl;


    temp=0;
    for (int k=0;k<=ll1;k++){temp+=(yy1[k+1]-yy1[k])*(pp[k+1]+pp[k]);}
    temp=temp/2.0;
    cout<< "Area under P(N) : " << temp <<endl;

    hh=nav;
    kk=aa*hh*hh;
    for (int k=0;k<=ll;k++){pp[k]=pp[k]*nav;}
    for (int k=0;k<=ll;k++){yy1[k]=yy1[k]/nav;}   
    for (int k=0;k<=ll;k++){z[k]=z[k]/nav;}
    for (int k=0;k<=ll;k++){dzdx[k]=dzdx[k]/nav;}
    
    

    for (int k=1;k<=ll;k++){chenddz[k]=chend[k]/dzdx[k];}
    chenddz[0]=2*chenddz[1]-chenddz[2]; //Linear interpolation

    temp=0;
    for (int k=0;k<=ll1;k++){temp+=(yy1[k+1]-yy1[k])*(pp[k+1]+pp[k]);}
    temp=temp/2.0;
    cout<< "Area under P(N) : " << temp <<endl;

    temp=0;
    for (int k=0;k<=ll1;k++){temp+=(yy1[k+1]-yy1[k])*(pp[k+1]*yy1[k+1]+pp[k]*yy1[k]);}
    temp=temp/2.0;
    cout<< "Average N : " << temp <<endl;
    
    cout<<"H: "<<hh << "  K: "<<kk<<endl;

    //Calculating monomers
    temp=0;
    for (int i=0;i<=ll2;i++){temp+=(m[i+1]+m[i])*(z[i+1]-z[i])/2;}
    perc=(temp/(1*sig)-1)*100;
    if (perc<0) perc=-perc;
    cout<< " MONOMERS everywhere: "<< temp<<endl;
    cout<< " Monomers expected: "<< 1*sig<<endl;
    cout<< " Percentage Difference: " << perc<<endl;
    
   //Calculating sigma
    temp=0;
    for (int i=0;i<=ll2;i++){temp+=(chenddz[i+1]+chenddz[i])*(z[i+1]-z[i])/2;}
    cout << "Sigma from chenddz "<< temp<<endl;
    
    //Calculating m(U) for checking
    for (int k=0;k<=ll;k++) {test[k]=(1-xs[k])*(1.0+2*hh*z[k]+kk*pow(z[k],2));}

    stringstream rxit1;
    rxit1 << "temp.dat";
    ofstream writerxit1;
    writerxit1.open(rxit1.str().c_str());
    writerxit1 <<"#1.U  2.N1(U) 3.zx 4.m 5. Chain end 6.md 7.dzdu 8. RHS 9. Chain end dz 10. P(N) 11. dn/du 12.test "<< endl;
    for(int k=0;k<ll1;k++) {
    writerxit1 <<xs[k]<<" "<<yy1[k]<<" "<<z[k]<<" "<<m[k]<<" "<< chend[k]<<" "<< md[k]<<" "<< dzdx[k]<<" "<< rhs[k]<<" "<< chenddz[k]<<" "<< pp[k]<< " " << dydx1[k]<<" "<< test[k] <<endl;
    }
    writerxit1.close();


    //Calculation of average chain end distance
    meandis=0;
    for(int i=0;i<=ll2;i++) {meandis+=(chend[i+1]*z[i+1]+chend[i]*z[i])*dxx/2.0;}
    meandis=meandis/sig;




    //Calculating the free energy

    //Entropical part
    ff1=0;
    for(int i=0;i<=ll2;i++) {ff1+=(z[i+1]*m[i+1]+z[i]*m[i])*dxx/2.0;}
    ff1=0.5*ff1;

    //Excluded volume part //Need to change this as well
    ff2=0;
    // for(int i=str;i<=ll2;i++) {ff2+=(dzdx[i+1]*(1.0-xs[i+1])*m[i+1]+dzdx[i]*(1.0-xs[i])*m[i])*dxx/2.0;}
    for(int i=0;i<=ll2;i++) {ff2+=((1.0-xs[i+1])*m[i+1]+(1.0-xs[i])*m[i])*(z[i+1]-z[i])/2.0;}

    fftot=ff1+ff2;


    ostringstream ss1,ss2,ss3,ss4;
    ss1 <<fixed << setprecision(prec1)<<hh;
    ss2 <<fixed<< setprecision(prec2)<<kk;
    ss3 <<fixed<< setprecision(prec2)<<aa;



    string title2="a_"+ ss3.str() +"_extra.dat";

    stringstream rxit2;
    rxit2 << title2;
    ofstream writerxit2;
    writerxit2.open(rxit2.str().c_str());

    writerxit2 <<"# 1.Sigma 2.Height 3.F_1 4.F_2 5.F_tot 7.Mean Chain end distance 8.Percentage error 9.H 10. K 11. a"<< endl;
    writerxit2 <<sig<<" "<<z[ll]<<" "<< ff1<<" "<<ff2<<" "<< fftot <<" "<<meandis<<" "<<perc<<" " << hh<<" " << kk<< " "<<aa<<endl;
    writerxit2.close();


return 0;
}

/////////////////
///END OF MAIN///
/////////////////




