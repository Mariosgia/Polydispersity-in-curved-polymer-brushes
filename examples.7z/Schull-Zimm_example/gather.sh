#!/bin/bash
rr=(R*)
for i in "${rr[@]}"
do

	echo $i
	cd "$i"
	rm ./data.dat
	echo "# 1.Sigma 2.Height/N_ave. 3.EEZ height/N_ave. 4.F_1 5.F_2 6.F_tot 7.Mean Chain end distance/N_ave. 8.Percentage error above EEZ 9.A" >> ./data.dat

	aanam=(A*)

	for j in "${aanam[@]}"
	do

		aa=$(echo "$j"| grep -Eo '[0-9]+[.]+[0-9]+|[0-9]')
		cd "$j"

		sig=$(tail -n 1 ./*extra* | awk '{print $1}')
		sig=$(awk -v r1=$sig -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2 }')

		#sig=$(bc <<< "scale=10; $sig * sqrt($aa) * $aa^(1)")
		hei=$(tail -n 1 ./*extra*  | awk '{print $2}')
		hei=$(awk -v r1=$hei -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) }')
		#hei=$(bc <<< "scale=10; $hei * sqrt($aa) ")
		eezhei=$(tail -n 1 ./*extra*  | awk '{print $3}')
		eezhei=$(awk -v r1=$eezhei -v r2=$aa 'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2)  }')
		# eezhei=$(bc <<< "scale=10; $eezhei *  sqrt($aa)")
		ff1=$(tail -n 1 ./*extra*  | awk '{print $4}')
		ff1=$(awk -v r1=$ff1 -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2^2 }')
		#ff1=$(bc <<< "scale=10; $ff1 *  sqrt($aa)* $aa^(2)")
		ff2=$(tail -n 1 ./*extra*  | awk '{print $5}')
		ff2=$(awk -v r1=$ff2 -v r2=$aa 'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2^2 }')
		#ff2=$(bc <<< "scale=10; $ff2 *  sqrt($aa) * $aa^(2)")
		fftot=$(tail -n 1 ./*extra*  | awk '{print $6}')
		fftot=$(awk -v r1=$fftot -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2^2 }')
		#fftot=$(bc <<< "scale=10; $fftot *  sqrt($aa)* $aa^(2)")
		meandis=$(tail -n 1 ./*extra*  | awk '{print $7}')
		meandis=$(awk -v r1=$meandis -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2)  }')
		per=$(tail -n 1 ./*extra*  | awk '{print $8}')

		printf "$sig $hei $eezhei $ff1 $ff2 $fftot $meandis $per $aa \n" >> ../data.dat

		cd ..

	done

	cd ..

done
