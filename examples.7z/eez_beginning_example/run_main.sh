#!/bin/bash
# hh=( "0.01"  )
#Script that runs solver found in FILES for different geometries
# and different A's. The gather.sh script then collects the data for each geometry
#converting along the way the grafting density the height etc.
#run.sh is actually run through here and is the one responsible for finding the right U1 value


#topo=1 #cylinder
topo=0 #sphere

# con=-1 #concave
con=1 #convex

#1/hh chosen here is R/N_ave. in spherical case and 1/2*hh is R/N_ave. in cylinder case
#ratio=( "0.4" "0.5" "0.6") #R/N_ave.
#ratio=( "0.1" "0.2" "0.3") 
ratio=( "0.9" "1.0")
#ratio=( "0.7" "0.8") 
len=${#ratio[@]}

nam=$(pwd)
mafi="$nam/FILES"



#REAL H
declare -a hh

for (( i=0; i<${len}; i++ ));
do
	hh[$i]=$( awk -v r1="${ratio[$i]}" -v r2=$con -v r3=$topo 'BEGIN{ OFMT = "%2.8f"; print r2*1.0/(r1+r3*r1)  }' )
	echo ${hh[$i]}
done

#aa=($(seq 0.05 0.05 1.50)) #Range of real values of A
aa=($(seq 1.55 0.05 2.0))

for i in "${hh[@]}"
do


	rr=$( awk -v r1=$i -v r2=$topo -v r3=$con 'BEGIN{ OFMT = "%2.1f"; print  r3*(1.0)/(r1+r2*r1) }' ) #R/N_ave.
	echo $rr
	#mkdir "R_$rr"

	cd "R_$rr"

	for j in "${aa[@]}"
	do
		mkdir "A_$j"
		cd "A_$j"

		hh1=$( awk "BEGIN{ print sqrt($j)*$i }")  #Rescaled H and K so that when we return back to proper units we get the same #REAL radius
		kk1=$( awk -v r1=$hh1 -v r2=$topo  'BEGIN{ OFMT = "%2.10f"; print  r1*r1*(1-r2) }' ) #0 if cylinder and H^2 if sphere
		echo "H is $hh1"

		cp ../../run.sh .
		nohup ./run.sh $hh1 $kk1 "$mafi" > run.out &
#		./run.sh $hh1 $kk1 "$mafi"
		last_pid="$!"
		cd ..
	done
	#echo $last_pid
	#wait $last_pid
	cd ..
	
done
