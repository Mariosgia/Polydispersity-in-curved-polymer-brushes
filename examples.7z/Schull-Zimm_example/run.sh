#!/bin/bash
# hh=( "0.01"  )
#Script that runs solver found in FILES for different geometries
# and different A's. The gather.sh script then collects the data for each geometry
#converting along the way the grafting density the height in real units etc.


# topo=1 #cylinder
topo=0 #sphere

con=-1 #concave
# con=1 #convex

#1/hh chosen here is R/N_ave. in spherical case and 1/2*hh is R/N_ave. in cylinder case
ratio=( "2"  )  #R/N_ave.
# ratio=( "10000")  #R/N_ave.
# ratio=( "2" )
# ratio=( "10000" )  #R/N_ave.

len=${#ratio[@]}



#REAL H
declare -a hh

for (( i=0; i<${len}; i++ ));
do
	hh[$i]=$( awk -v r1="${ratio[$i]}" -v r2=$con -v r3=$topo 'BEGIN{ OFMT = "%2.8f"; print r2*1.0/(r1+r3*r1)  }' )

done

#aa=($(seq 0.05 0.05 1.00))
aa=($(seq 0.8 0.05 1.0))

for i in "${hh[@]}"
do


	rr=$( awk -v r1=$i -v r2=$topo -v r3=$con 'BEGIN{ OFMT = "%2.10f"; print  r3*(1.0)/(r1+r2*r1) }' ) #R/N_ave.

	echo $rr

#	mkdir "R_$rr"
	cd "R_$rr"

	for j in "${aa[@]}"
	do
		mkdir "A_$j"
		cd "A_$j"
		echo "A_$j"
		cp ../../FILES/out .
		cp ../../FILES/details.dat .
		cp ../../FILES/prob_dis.dat .
		cp ../../FILES/cumulative.dat .
		hh1=$( awk "BEGIN{ print sqrt($j)*$i }")  #Rescaled H and K so that when we return back to proper units we get the same #REAL radius
		kk1=$( awk -v r1=$hh1 -v r2=$topo  'BEGIN{ OFMT = "%2.10f"; print  r1*r1*(1-r2) }' ) #0 if cylinder and H^2 if sphere
		echo "H is $hh1"

		# nohup ./out 0 $hh1 $kk1 &
		./out 0 $hh1 $kk1


		cd ../

	done
	last_pid="$!"
	echo $last_pid
	wait $last_pid
	cd ..
done
