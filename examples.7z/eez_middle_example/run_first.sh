#!/bin/bash

hh1=$1
kk1=$2
mafi=$3

du=0.0025
duu=0.0075 #Searches around U1 +- duu and U2+- duu for every du 

mkdir "U1_0_U2_0"
cd "U1_0_U2_0"

cp "$mafi/out_no_eez" .
cp "$mafi/details.dat" .
cp "$mafi/prob_dis.dat" .
cp "$mafi/cumulative.dat" .
./out_no_eez $hh1 $kk1
ext_stat=$?
echo "Exit status: $ext_stat"

if [ $ext_stat -eq 0 ]
then
	cd ..
	mkdir temp
	cp -r "U1_0_U2_0" "temp"

	echo "# 1.Sigma 2.Height 3.EEZ height 4.F_1 5.F_2 6.F_tot 7.Mean Chain end distance 8.Percentage error 9.Sign 10.Conv. factor 11. dzdx<0 rate 12. eps(U)<0 rate 13. Sig_c false rate 14.U1 15.U2 " >> ./data.dat
	cd U1_0_U2_0
	temp_str=$( tail -n 1 ./*extra* )
	printf "$temp_str \n" >> ../data.dat
	cd ..



	echo "Successful solution with no eez" >> status.txt
	exit 1
fi

cd ..

echo "No solution for no EEZ" >>status.txt

mkdir "finder"
cd "finder"

cp "$mafi/out_finder" .
cp "$mafi/details.dat" .
cp "$mafi/prob_dis.dat" .
cp "$mafi/cumulative.dat" .
./out_finder $hh1 $kk1

cp "./U1_U2_found.dat" ../
cd ..
##ext_stat=$?
##Then run code for successive U1s and U2s

u1=$( awk '{print $1}' ./U1_U2_found.dat )
u2=$( awk '{print $2}' ./U1_U2_found.dat )


u2low=$( awk -v r1=$u2 -v r2=$duu 'BEGIN{ OFMT = "%2.4f"; print r1-r2  }' )
u2high=$( awk -v r1=$u2 -v r2=$duu 'BEGIN{ OFMT = "%2.4f"; print r1+r2  }' )

u1low=$( awk -v r1=$u1 -v r2=$duu 'BEGIN{ OFMT = "%2.4f"; print r1-r2  }' )
u1high=$( awk -v r1=$u1 -v r2=$duu 'BEGIN{ OFMT = "%2.4f"; print r1+r2  }' )


u2s=($(seq $u2low $du $u2high))
u1s=($(seq $u1low $du $u1high)) 
declare -a pids=()
k=0
for i in "${u2s[@]}"
do

    tst0=$( awk -v num1=0 -v num2=$i 'BEGIN{ print (num2"">num1) ? "1" : "0" }' )
    if [ $tst0 -eq 0 ] 
    then
        continue
    else 
        for j in "${u1s[@]}"
        do  
	    
            tst1=$( awk -v num1=0 -v num2=$j 'BEGIN{ print (num2"">num1) ? "1" : "0" }' )
            tst2=$( awk -v num1=$j -v num2=$i 'BEGIN{ print (num2"">num1) ? "1" : "0" }' )
            
            if [ $tst1 -eq 0 ] || [ $tst2 -eq 0 ]
            then
                continue
            else
                echo "U1_${j}_U2_${i}"
               
                mkdir "U1_${j}_U2_${i}"
                cd "U1_${j}_U2_${i}"
                cp "$mafi/out_u1_u2" .
                cp "$mafi/details.dat" .
                cp "$mafi/prob_dis.dat" .
                cp "$mafi/cumulative.dat" .
               # nohup ./out_u1_u2 $j $i $hh1 $kk1 &
		./out_u1_u2 $j $i $hh1 $kk1 
	        pids+=($!)
		k=$((k+1))	
                cd .. 
            fi
        done
        
    fi
    
done

#for pid in ${pids[*]};
#do
#    wait $pid
#done

#sleep 600


echo "# 1.Sigma 2.Height 3.EEZ height 4.F_1 5.F_2 6.F_tot 7.Mean Chain end distance 8.Percentage error 9.Sign 10.Conv. factor 11. dzdx<0 rate 12. eps(U)<0 rate 13. Sig_c false rate 14.U1 15.U2 " >> ./data.dat


##Collect data
cd U1_0_U2_0
temp_str=$( tail -n 1 ./*extra* )
#tail -n 1 ./*extra*  &>> ../data.dat
printf "$temp_str \n" >> ../data.dat
cd ..




for i in "${u2s[@]}"
do

    tst0=$( awk -v num1=0 -v num2=$i 'BEGIN{ print (num2"">num1) ? "1" : "0" }' )
    if [ $tst0 -eq 0 ] 
    then
        continue
    else 
        for j in "${u1s[@]}"
        do  
            tst1=$( awk -v num1=0 -v num2=$j 'BEGIN{ print (num2"">num1) ? "1" : "0" }' )
            tst2=$( awk -v num1=$j -v num2=$i 'BEGIN{ print (num2"">num1) ? "1" : "0" }' )
            
            if [ $tst1 -eq 0 ] || [ $tst2 -eq 0 ]
            then
                continue
            else
                echo "U1_${j}_U2_${i}"
                cd "U1_${j}_U2_${i}"
                temp_str=$( tail -n 1 ./*extra* )
                printf "$temp_str \n" >> ../data.dat
                
                cd .. 
            fi
        done
        
    fi
    
done

cp "$mafi/cleaner.py" .
python3 cleaner.py

u1final=$( awk '{print $1}' ./final_u1_u2.dat )
u2final=$( awk '{print $2}' ./final_u1_u2.dat )

mkdir "temp"
cp -r "U1_${u1final}_U2_${u2final}" "temp"
cp -r "finder" "temp"
cp "status.txt" "temp"
cp "U1_U2_found.dat" "temp"
cp "data.dat" "temp"


