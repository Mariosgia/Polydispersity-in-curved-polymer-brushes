#!/bin/bash

ext_stat=1 #If the code fails then this will be either 1 or 2 but if it is zero then it was successful
cnt=0 #Lets you know how many time has U1 has changed directions

hh1=$1
kk1=$2
mafi=$3

#First we run the U1=0 case
u1=0
mkdir "U1_$u1"
cd "U1_$u1"
cp "$mafi/out_no_eez" .
cp "$mafi/details.dat" .
cp "$mafi/prob_dis.dat" .
cp "$mafi/cumulative.dat" .
./out_no_eez $hh1 $kk1

ext_stat=$?
echo "Exit status: $ext_stat"
if [ $ext_stat -eq 0 ]
then
	cd ..
	echo "Successful solution for U1=0" >> status.txt
	exit 1
fi
cd ..
echo "No solution for U1=0" >>status.txt



u1=0.05
cnt=0
sim_stat=1	#simulation state of last simulation
sim_name="U1_$u1" #simulation name of the last simulation that



while [ $cnt != 3 ];
do
	mkdir "U1_$u1"
	cd "U1_$u1"
	cp "$mafi/out_eez" .
	cp "$mafi/details.dat" .
	cp "$mafi/prob_dis.dat" .
	cp "$mafi/cumulative.dat" .

	printf "U1 is $u1 \n "
	./out_eez $u1 $hh1 $kk1

	ext_stat=$?
	echo "Exit status: $ext_stat"

	if [[ $cnt -eq 0 ]]
	then
		printf "\n\n\n\n Count 0 \n\n\n\n"

		if [ $ext_stat -eq 1 ] || [ $ext_stat -eq 0 ] || [ $ext_stat -eq 3 ]
		then
			u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.3f"; print  r1+0.05 }' ) #Increase U1 by 0.05
		fi

		if [ $ext_stat -eq 2 ] #In this case the distance has gone negative
		then
			u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.3f"; print  r1-0.05+0.01 }' ) #Decrease U1 by 0.05
			cnt=1
			printf "\n\n\n\n END of Count 0 \n\n\n\n"
			cd ..
			continue
		fi
	fi




	if [[ $cnt -eq 1 ]]
	then
		printf "\n\n\n\n Count 1 \n\n\n\n"
		if [ $ext_stat -eq 1 ] || [ $ext_stat -eq 0 ] || [ $ext_stat -eq 3 ]  #Either out of range or has converged, but not to the lowest free energy
		then
			u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.3f"; print  r1+0.01 }' ) #Increase U1 by 0.05
		fi

		if [ $ext_stat -eq 2 ] #In this case the distance has gone negative
		then
			u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.3f"; print  r1-0.01+0.001 }' ) #Decrease U1 by 0.05
			cnt=2
			printf "\n\n\n\n END of Count 1 \n\n\n\n"
			cd ..
			continue
		fi
	fi



	if [[ $cnt -eq 2 ]]
	then

		if [ $ext_stat -eq 1 ] || [ $ext_stat -eq 0 ] || [ $ext_stat -eq 3 ]  #Either out of range or has converged, but not to the lowest free energy
		then
			printf "\n\n\n\n Count 2 \n\n\n\n"
			sim_stat=$ext_stat
			sim_name="U1_$u1"
			u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.3f"; print  r1+0.001 }' ) #Increase U1 by 0.001
		fi

		if [ $ext_stat -eq 2 ] #In this case the distance has gone negative
		then
			# u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.4f"; print  r1-0.0001 }' ) #Decrease U1 by 0.001
			cnt=3
			printf "\n\n\n\n END of Count 2 \n\n\n\n"
			cd ..
			mkdir temp
			#if the previous simulation was successful we keep that one, Otherwise we keep the one where z(U) went negative
			if [ $sim_stat -eq 0 ]
			then
				cp -r $sim_name temp
			else
				cp -r "U1_$u1" temp
			fi

			cp "nohup.out" temp
			cp "status.txt" temp
			ls | grep -xv "temp" | xargs rm -r
			cp -r temp/* .
			rm -r temp
			echo "Got a negative distance on count 3" >> status.txt

		fi
	fi



	#
	# if [[ $cnt -eq 3 ]]
	# then
	# 	printf "\n\n\n\n Count 3 \n\n\n\n"
	# 	if [ $ext_stat -eq 1 ] || [ $ext_stat -eq 0 ] #Either out of range or has converged, but not to the lowest free energy
	# 	then
	# 		u1=$( awk -v r1=$u1   'BEGIN{ OFMT = "%2.4f"; print  r1+0.0001 }' ) #Increase U1 by 0.05
	# 		if [ $ext_stat -eq 0 ]
	# 		then
	# 			sim_name="U1_$u1"
	# 			sim_stat=0
	# 		fi
	#
	# 	fi
	# fi





	cd .. #Leaves the U1 folder




done
