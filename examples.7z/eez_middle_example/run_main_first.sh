#!/bin/bash
# hh=( "0.01"  )
#Script that runs solver* found in FILES for different geometries specified by topo and con
# and different A's. Only need to run_main_first.sh since run_first.sh is used by this script


#topo=1 #cylinder
topo=0 #sphere

# con=-1 #concave
con=1 #convex

#1/hh chosen here is R/N_ave. in spherical case and 1/2*hh is R/N_ave. in cylinder case
#ratio=(  "0.5" "1.0" "2.0" "5.0" "10.0" "100.0" "1000.0" "10000.0")  #R/N_ave.
ratio=(  "0.01")  #R/N_ave
#ratio=(  "0.05")  #R/N_ave.
#ratio=(  "1.0" )  
#ratio=(  "2.0" )  
#ratio=(  "5.0" )  
#ratio=( "10.0" )  
#ratio=( "100.0" )  
#ratio=( "1000.0" )  
#ratio=( "10000.0" )  


len=${#ratio[@]}

nam=$(pwd)
mafi="$nam/FILES"



#REAL H
declare -a hh

for (( i=0; i<${len}; i++ ));
do
	hh[$i]=$( awk -v r1="${ratio[$i]}" -v r2=$con -v r3=$topo 'BEGIN{ OFMT = "%2.8f"; print r2*1.0/(r1+r3*r1)  }' )
	echo ${hh[$i]}
done

aa=($(seq 0.1 0.1 3.00)) #Range of real values of A

#aa=($(seq 1 1 1)) #Range of real values of A


for i in "${hh[@]}"
do


	rr=$( awk -v r1=$i -v r2=$topo -v r3=$con 'BEGIN{ OFMT = "%2.2f"; print  r3*(1.0)/(r1+r2*r1) }' ) #R/N_ave.
	echo $rr
	mkdir "R_$rr"

	cd "R_$rr"

	for j in "${aa[@]}"
	do
		mkdir "A_$j"
		cd "A_$j"

		hh1=$( awk "BEGIN{ print sqrt($j)*$i }")  #Rescaled H and K so that when we return back to proper units we get the same #REAL radius
		kk1=$( awk -v r1=$hh1 -v r2=$topo  'BEGIN{ OFMT = "%2.10f"; print  r1*r1*(1-r2) }' ) #0 if cylinder and H^2 if sphere
		echo "H is $hh1"
        
        cp ../../run_first.sh .
#        cp ../../cleaner.sh .
#        ./run_first.sh $hh1 $kk1 "$mafi" 
	nohup ./run_first.sh $hh1 $kk1 "$mafi" > run.out &
		
		cd ..
	done
	
	cd ..
	
done
