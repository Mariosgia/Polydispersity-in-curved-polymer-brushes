import numpy as np
import os
import subprocess

data=np.loadtxt("./data.dat", skiprows=0)


sig=data[:,0]
ftot=data[:,5]
perc=data[:,7]
sgn=data[:,8]
conv=data[:,9]
dzdxrate=data[:,10]
epsrate=data[:,11]
sigcrate=data[:,12]
u1s=data[:,13]
u2s=data[:,14]


#a=np.array([-1,2,3,-1])

datalen=len(data)

indices=np.arange(0,datalen,1)
indices_perc=[]
indices_conv=[]
indices_sgn=[]

for i in range(0,datalen):
    if perc[i]>1.0:
        indices_perc.append(i)
    if conv[i]>0.00001:
        indices_conv.append(i)
    if sgn[i]==3: #Convergence factor was oscillating
        indices_sgn.append(i)

failind=list(set(indices_perc) | set(indices_conv) | set(indices_sgn))


indices=list(set(indices)-(set(failind) & set(indices)))

if len(indices)==0:
    print("All runs failed to meet the basic criteria for convergence ")
    exit()

#Softer criteria i.e some points possibly have negative chain end density or negative dzdx or have points in the cumulative grafting density that are not where they are supposed to be
indices_sgn=[]

#Removing cases where some points have negative chain end density or negative dzdx
for i in range(len(indices)):
    if sgn[indices[i]]==2:
        indices_sgn.append(indices[i])

if len(indices_sgn)<len(indices):                                   #If all cases have sgn=2 then we keep all of them and move on the next criterium 
    indices=list(set(indices)-(set(indices_sgn) & set(indices)))

#Now we choose the points with the lowest rate of sigc_rate 
sigcratetemp=[]
for i in range(0,len(indices)):
    sigcratetemp.append(sigcrate[indices[i]])
sigcratetemp=np.array(sigcratetemp)

indices_lowsigrate=np.where(sigcratetemp == sigcratetemp.min())
indices1=[]
for i in range(0,len(indices_lowsigrate[0])):
    indices1.append(indices[indices_lowsigrate[0][i]])



#Now we choose the points with the lowest rate of free energy
f0=ftot[indices1[0]]
last_choice=indices1[0]
for i in range(1,len(indices1)):
    f1=ftot[indices1[i]]
    if f1< f0:
        f0=f1
        last_choice=indices1[i]

print("Difference between Percentage error of chosen solution and minimum perc : " +str(perc[last_choice]-np.array(perc).min()))

np.savetxt("final_u1_u2.dat",np.c_[u1s[last_choice],u2s[last_choice]],fmt='%1.4f')



