#!/bin/bash

#Gathers the data from R_*-A_* and produces a data sheet for each R_* with non-scaled values
rr=(R*)
for i in "${rr[@]}"
do

	echo $i
	cd "$i"
	rm ./data.dat
	echo "# 1.Sigma 2.Height 3.EEZ height 4.F_1 5.F_2 6.F_tot 7.Mean Chain end distance 8.Percentage error above EEZ 9.A 10.U1 11.Sign 12.Conv. factor" >> ./data.dat

	aanam=(A*)

	for j in "${aanam[@]}"
	do

		aa=$(echo "$j"| grep -Eo '[0-9]+[.]+[0-9]+|[0-9]')
		cd "$j"

		u1s=(U1*)
		u1=$(echo "${u1s}"| grep -Eo '[_]+[0-9]+[.]+[0-9]+|[_]+[0-9]')
		u1=$(echo "${u1:1}")

		cd U1*

		sig=$(tail -n 1 ./*extra* | awk '{print $1}')
		sig=$(awk -v r1=$sig -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2 }')
		#sig=$(bc <<< "scale=10; $sig * sqrt($aa) * $aa^(1)")
		hei=$(tail -n 1 ./*extra*  | awk '{print $2}')
		hei=$(awk -v r1=$hei -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) }')
		#hei=$(bc <<< "scale=10; $hei * sqrt($aa) ")
		eezhei=$(tail -n 1 ./*extra*  | awk '{print $3}')
		eezhei=$(awk -v r1=$eezhei -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2)  }')
		#eezhei=$(bc <<< "scale=10; $eezhei *  sqrt($aa)")
		ff1=$(tail -n 1 ./*extra*  | awk '{print $4}')
		ff1=$(awk -v r1=$ff1 -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2^2 }')
		#ff1=$(bc <<< "scale=10; $ff1 *  sqrt($aa)* $aa^(2)")
		ff2=$(tail -n 1 ./*extra*  | awk '{print $5}')
		ff2=$(awk -v r1=$ff2 -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2^2 }')
		#ff2=$(bc <<< "scale=10; $ff2 *  sqrt($aa) * $aa^(2)")
		fftot=$(tail -n 1 ./*extra*  | awk '{print $6}')
		fftot=$(awk -v r1=$fftot -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2) * r2^2 }')
		#fftot=$(bc <<< "scale=10; $fftot *  sqrt($aa)* $aa^(2)")
		meandis=$(tail -n 1 ./*extra*  | awk '{print $7}')
		meandis=$(awk -v r1=$meandis -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * sqrt(r2)  }')
		per=$(tail -n 1 ./*extra*  | awk '{print $8}')

		u1=$(awk -v r1=$u1 -v r2=$aa  'BEGIN{ OFMT = "%2.5f"; print  r1 * r2  }')

		sgn=$(tail -n 1 ./*extra* | awk '{print $9}')
		con=$(tail -n 1 ./*extra* | awk '{print $10}')
		cd ../..
		
		if awk "BEGIN {exit !($con >= 10E-5)}"; then
    			echo "Skipping this entry because coonvergence factor is too high"
			continue
		fi


		printf "$sig $hei $eezhei $ff1 $ff2 $fftot $meandis $per $aa $u1 $sgn $con \n" >> ./data.dat



	done

	cd ..

done
